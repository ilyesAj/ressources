package isty.iatic5.arlo.res.model;

/**
 * Enumération représentant le status de l'utilisateur
 * 
 * @author Clément Lefevre
 *
 */
public enum Status {
	Student,
	Teacher
}
